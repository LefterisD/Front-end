import React, { useState, useEffect } from "react";
import FeedBack from "./FeedBack";
import {
  PieChart,
  Cell,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Pie,
  ResponsiveContainer,
} from "recharts";

const COLORS = ["#8BD8BD", "#243665"];

const ProfGrade = ({ mistakes, wordCountProf, role, user, flag, setFlag }) => {
  const [data, setData] = useState([]);
  const [grade, setGrade] = useState(0);
  //const [weightSpell, setWeightSpell] = useState(0);
  const [weightGram, setWeightGram] = useState(0);
  const [weightPunc, setWeightPunc] = useState(0);
  let weightSpell = 0;
  //let weightGram = 0;
  //let weightPunc = 0;

  let countOrth1 = 0;
  let countSti1 = 0;
  let countGram1 = 0;
  const [countOrth, setcountOrth] = useState(0);
  const [countGram, setcountGram] = useState(0);
  const [countSti, setcountSti] = useState(0);

  let content;

  const fillData = (grade) => {
    if (grade) {
      let temp_data = [
        {
          name: "Βαθμός",
          value: grade,
        },
        {
          name: "_",
          value: 20 - grade,
        },
      ];
      setData(temp_data);
    } else {
      let temp_data = [
        { name: "Βαθμός", value: 0 },
        { name: "", value: 0 },
      ];
      setData(temp_data);
    }
  };

  const findGrade = () => {
    if (mistakes.length !== 0) {
      //Essay grading
      compute_grade(0);
    } else {
      compute_grade(1);
    }
  };

  const findCount = (item, firstTime) => {
    if (firstTime == 0) {
      countOrth1 = 0;
      countSti1 = 0;
      countGram1 = 0;
    }
    if (item.shortMessage == "Ορθογραφικό λάθος") {
      countOrth1++;
      setcountOrth(countOrth1); // dinei me to set sto countorth to athrisma
    } else if (
      item.shortMessage == "Ελέγξτε τη στίξη" ||
      item.shortMessage == ""
    ) {
      countSti1++;
      setcountSti(countSti1);
    } else if (item.shortMessage == "Επανάληψη λέξης") {
      countGram1++;
      setcountGram(countGram1);
    }
  };

  const compute_grade = (flag) => {
    if (flag === 0) {
      if (mistakes.length != 0) {
        let firstTime = 0;
        mistakes.map((item) => {
          findCount(item, firstTime); // vriskei ta lathi
          firstTime = 1;
        });
      }
      //Sydelestis 0-1 gia kathe kathgoria
      let orthPercentage = computeErrorPercentage(wordCountProf, countOrth);
      let gramPercentage = computeErrorPercentage(wordCountProf, countGram);
      let stiPercentage = computeErrorPercentage(wordCountProf, countSti);

      console.log("SPELLCOUNT", countOrth);

      //Get weights to compute grade
      getWeights(orthPercentage, gramPercentage, stiPercentage);
    } else {
      addEssay(0, 0, 0, wordCountProf, 10);
    }
  };

  //compute coefficient fro ypes of mistakes
  const computeErrorPercentage = (wordCount, errors) => {
    let count_1 = wordCount - errors;
    return count_1 / wordCount;
  };

  async function fetchMoviesJSON() {
    const response = await fetch(
      `http://127.0.0.1:5000/weights/by/${role}/${user}`
    );
    const weights = await response.json();
    return weights;
  }

  async function getWeights(orthPercentage, gramPercentage, stiPercentage) {
    const weights = await fetchMoviesJSON();

    let temp_grade =
      weights[0].spelling_w * orthPercentage +
      weights[0].grammar_w * gramPercentage +
      weights[0].punctuation_w * stiPercentage;

    temp_grade = Math.round(temp_grade * 10) / 10;
    fillData(temp_grade);
    setGrade(temp_grade);
    console.log("SPELL", weightSpell);
    console.log("GRADE", grade);
    console.log("TempGrade", temp_grade);
    console.log("wordcount", wordCountProf);

    addEssay(countOrth, countGram, countSti, wordCountProf, temp_grade);
    console.log("META");
  }

  const addEssay = (countOrth, countGram, countSti, wordCount, grade) => {
    fetch(
      `http://127.0.0.1:5000/essays/add/role/${role}/id/${user}/spelling/${countOrth}/grammar/${countGram}/puncutation/${countSti}/words/${wordCount}/${grade}`,
      {
        method: "POST",
      }
    ).then((results) => console.log(results));
  };

  useEffect(() => {
    if (flag === false) {
      console.log("FALSE");
      setFlag(true);
    } else {
      console.log("true");
      findGrade();
    }
  }, [mistakes]);

  if (mistakes.length !== 0) {
    content = (
      <div className="grade_box">
        <div className="grade_chart">
          <ResponsiveContainer width="100%" height={180}>
            <PieChart width={500} height={180} id="pie-grade">
              <Pie
                data={data}
                startAngle={180}
                endAngle={0}
                innerRadius={65}
                outerRadius={85}
                fill="#8884d8"
                paddingAngle={0}
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={COLORS[index % COLORS.length]}
                  />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="grade-text">
            <p>
              {grade}
              <span id="grade-span">/20</span>
            </p>
          </div>
        </div>
        <div className="content_feedback">
          <p id="title">Ήταν ικονοποιητική η βαθμολόγηση;</p>
          <div className="comments">
            <button>NAI</button>
            <button>OXI</button>
          </div>
        </div>
      </div>
    );
  } else {
    content = <div></div>;
  }
  return <div>{content}</div>;
};
export default ProfGrade;
