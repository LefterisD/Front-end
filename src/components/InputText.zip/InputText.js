import React, { useState, useEffect } from "react";
import Essays from "./Essays";
import HighlightText from "./HighlightText";
import { HighlightWithinTextarea } from "react-highlight-within-textarea";
import Tippy from "@tippyjs/react";
import "tippy.js/dist/tippy.css";
import Charts from "./Charts";

const InputText = ({
  setInputText,
  getMistakes,
  mistakes,
  setWordsToHighlight,
  setcountGram,
  countGram,
  setcountOrth,
  countOrth,
  setcountSti,
  countSti,
  setWordsOrth,
  setWordsGram,
}) => {
  //const [textareaValue, setTextareaValue] = useState("");
  const [textAreaInput, setTextAreaInput] = useState("");
  const [words_json, setWordsJson] = useState([]);
  //const [tooltipMessage, setTooltipMessage] = useState("");
  const [tooltipReplacements, setTooltipReplacements] = useState([]);
  const [characters, setCharacters] = useState(0);
  const [wordCount, setWordCount] = useState(0);

  let words = [];
  let tooltipMessage = "";
  let tooltipshortMessage = "";
  let replacement_words = [];
  let fakeWordsOrth = [];
  let fakeWordsGram = [];

  const inputTextHandler = (e) => {
    let input_value = e.target.value;
    //input_value = input_value.replace(/\n/g, "");
    //input_value = " ".repeat(1) + input_value;
    //input_value = input_value.replace(/\s+/g, " ").trim();
    let char_count = input_value.length;
    let w_count = input_value.split(" ").length;

    setInputText(input_value);
    setTextAreaInput(input_value);
    setCharacters(char_count);
    setWordCount(w_count);
  };

  //vazei sto map tis lekseis kai to poses fores einai lathos
  const setOrthWords = (word) => {
    let counter = 0; // xrisimopoieite gia na elegxoume ama mia leksi uparxei idi mesa sto map
    if (fakeWordsOrth.length != 0) {
      fakeWordsOrth.map((item) => {
        //console.log("Mpike sto map");
        if (item.word === word) {
          //console.log("Yparxei idia leksi",item.word);
          // console.log("omoia", word);
          item.count = item.count + 1;
          counter = 1;
        }
      });
      if (counter == 0) {
        // console.log("DEn Yparxei i leksi");
        let newobject = {
          word: word,
          count: 1,
        };
        fakeWordsOrth.push(newobject);
      }
    } else {
      //console.log(" pinakas kenos");
      let newobject = {
        word: word,
        count: 1,
      };
      fakeWordsOrth.push(newobject);
    }
  };

  const setGramWords = (word) => {
    let counter = 0; // xrisimopoieite gia na elegxoume ama mia leksi uparxei idi mesa sto map
    if (fakeWordsGram.length != 0) {
      fakeWordsGram.map((item) => {
        //console.log("Mpike sto map");
        if (item.word === word) {
          //console.log("Yparxei idia leksi",item.word);
          // console.log("omoia", word);
          item.count = item.count + 1;
          counter = 1;
        }
      });
      if (counter == 0) {
        // console.log("DEn Yparxei i leksi");
        let newobject = {
          word: word,
          count: 1,
        };
        fakeWordsGram.push(newobject);
      }
    } else {
      //console.log(" pinakas kenos");
      let newobject = {
        word: word,
        count: 1,
      };
      fakeWordsGram.push(newobject);
    }
  };

  //count mistakes for charts
  const findCount = (item, word, firstTime) => {
    if (firstTime == 0) {
      countOrth = 0;
      countSti = 0;
      countGram = 0;
    }
    if (item.shortMessage == "Ορθογραφικό λάθος") {
      countOrth++;
      setcountOrth(countOrth); // dinei me to set sto countorth to athrisma
      setOrthWords(word); // gia na stelnw tin leksi pou einai orthografika lathos
    } else if (
      item.shortMessage == "Ελέγξτε τη στίξη" ||
      item.shortMessage == ""
    ) {
      countSti++;
      setcountSti(countSti);
    } else if (item.shortMessage == "Επανάληψη λέξης") {
      countGram++;
      setcountGram(countGram);
      setGramWords(word);
    }
  };

  //vriskei tis lathos leksis mia mia
  const wrongWord = (item) => {
    let offset = item.context.offset;
    let length = item.context.length;
    let sentence = item.context.text;
    // To get only the mistake slice from (offset to offset + length) e.g offset = 3  length = 5 => slice(3,8)
    let word1 = sentence.slice(offset, offset + length);
    return word1;
  };

  // This functions finds all the mistakes (words) the user made and puts them in an array that then is returned to the highlight component to highlight the correspponding words
  const findWrongWords = (mistakes) => {
    if (mistakes.length != 0) {
      let firstTime = 0;
      words = [];
      mistakes.map((item) => {
        let word = wrongWord(item); // vriskei tin leksi
        findCount(item, word, firstTime); // vriskei ta lathi
        firstTime = 1;
        words.push(word);
      });
      setWordsOrth(fakeWordsOrth);
      setWordsGram(fakeWordsGram);
      return words;
    } else {
      // if mistakes array is empty use a placeholder for the words
      words = [];
      words.push(["placeholder"]);
      return words;
    }
  };

  useEffect(() => {
    fakeWordsOrth = [];
    fakeWordsGram = [];
    setcountOrth(0);
    setcountGram(0);
    setcountSti(0);
    setWordsToHighlight(findWrongWords(mistakes));
    prepare_words_for_highlight();
  }, [mistakes]);

  /*---------------------------------Toolip--------------------------------*/

  const tooltip_content = (wrong_word) => {
    replacement_words = [];
    mistakes.map((item) => {
      let offset = item.context.offset;
      let length = item.context.length;
      let sentence = item.context.text;
      // To get only the mistake slice from (offset to offset + length) e.g offset = 3  length = 5 => slice(3,8)
      let word = sentence.slice(offset, offset + length);
      //prepei na mpei se sinartisi
      if (word === wrong_word) {
        let message = item.message;
        let shortMessage = item.shortMessage;
        tooltipshortMessage = shortMessage;
        tooltipMessage = message;
        let repls = item.replacements;
        let sliced = repls.slice(0, 2);
        sliced.map((repl) => {
          replacement_words.push(repl.value);
        });
        //console.log(replacement_words);
      }
    });
  };
  //Sets different background color for the highlighted word based on type of mistake
  const pick_color = (mistakes, word) => {
    let class_name = "";
    mistakes.map((item) => {
      let match = wrongWord(item);
      if (word === match) {
        let message = item.shortMessage;
        if (message == "Ορθογραφικό λάθος") {
          class_name = "blue";
        } else if (message == "Ελέγξτε τη στίξη" || message == "") {
          class_name = "yellow";
        } else if (message == "Επανάληψη λέξης") {
          class_name = "green";
        }
      }
    });
    return class_name;
  };

  const prepare_words_for_highlight = () => {
    //words_json = [];

    if (words.length != 0) {
      let temp_arr = [];
      words.map((item, index) => {
        let temp_item = {
          highlight: item,
          enhancement: ToolTip,
          className: pick_color(mistakes, item),
        };
        temp_arr.push(temp_item);
      });
      setWordsJson(temp_arr);
    }
  };

  function ToolTip(props) {
    tooltip_content(props.data.text); // call the function to update the tooltip message state
    console.log(props.data);
    const content = (
      <div
        style={{
          whiteSpace: "pre",
          overflow: "hidden",
          textOverflow: "ellipsis",
          backgroundColor: "transparent",
        }}
      >
        <div className="tooltip-message">
          <div className="tooltp-content">
            <h1 className="tooltip-header">{tooltipshortMessage}</h1>
            <p className="tooltip-info">{tooltipMessage}</p>
            <div className="rightwords">
              {replacement_words.map((ww, count) => (
                <button className="new-word">{ww}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
    const overlayStyle = {
      position: "absolute",
      height: "50%",
      width: "100%",
      background: "transparent",
      zIndex: 1,
    };

    return (
      <mark style={{ position: "relative" }}>
        <Tippy content={content} maxWidth="400px">
          <mark style={overlayStyle}></mark>
        </Tippy>
        <props.MarkView />
      </mark>
    );
  }
  /*---------------------------------Toolip--------------------------------*/

  return (
    <div className="content">
      <div className="text-box-check">
        <form>
          <HighlightWithinTextarea
            id="textarea-box2"
            value={textAreaInput}
            highlight={words_json}
            onChange={inputTextHandler}
            containerClassName="textarea-container"
            placeholder="Γράψτε εδώ..."
          />
          <div className="footer">
            <div className="word-count">
              <div className="words">
                <span className="number-color">{wordCount}</span>:words
              </div>
              <div className="chars">
                <span className="number-color">{characters}</span>:chars
              </div>
            </div>
            <input
              type="submit"
              onClick={getMistakes}
              value="Έλεγχος"
              id="check-text-btn"
            />
          </div>
        </form>
      </div>
      <div className="svgbox" styles="overflow: hidden;">
        <div id="top-svg"></div>
      </div>
    </div>
  );
};

export default InputText;
